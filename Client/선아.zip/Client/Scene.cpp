#include "stdafx.h"
#include "Scene.h"


CScene::CScene()
{
}

CScene::CScene(CObj * pPlayer)
	: m_pPlayer(pPlayer)
{
}


CScene::~CScene()
{
}
