#include "stdafx.h"
#include "Scroll_Manager.h"

int CScroll_Manager::m_iScrollX = 0;
CScroll_Manager::CScroll_Manager()
{
}


CScroll_Manager::~CScroll_Manager()
{
}
