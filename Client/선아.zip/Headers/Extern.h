#pragma once

extern HWND g_hWND; 
